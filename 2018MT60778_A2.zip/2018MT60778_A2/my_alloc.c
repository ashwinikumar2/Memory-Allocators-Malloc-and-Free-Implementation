#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <stdbool.h>
struct Node { 
    struct Node *prev;
    struct Node *next;
    int length; 
} block; 

struct Node1 {
	int leftout_free_space;
	int b,c,d,e,f; 

} heapinfo;

struct Node* head;
struct Node1* heapinfo_node;

int my_init()
{
	head=mmap (NULL,4096, PROT_READ | PROT_WRITE, MAP_PRIVATE|MAP_ANON, -1,0);
	head->prev=NULL;
	head->next=NULL;
	head->length=4096-sizeof(block)-sizeof(heapinfo);

	heapinfo_node=(void*)head+4096-sizeof(heapinfo);
	heapinfo_node->leftout_free_space=0;
	heapinfo_node->b=sizeof(heapinfo)+sizeof(block);
	heapinfo_node->c=4096-2*sizeof(block)-sizeof(heapinfo);
	heapinfo_node->d=0;
	heapinfo_node->e=head->length;
	heapinfo_node->f=head->length;
	return 0;
}

void* my_alloc(int count)
{	
	if(count%8!=0 || count==0 ||count>4096-2*sizeof(block)-sizeof(heapinfo)){
		return NULL;
	}

	struct Node* dummy3=head;

	while(dummy3->next!=NULL)
	{
		dummy3=dummy3->next;
		if(dummy3->length>=count)
			break;
	}
	if(dummy3->length<count+sizeof(block) && head->length<count+sizeof(block))
		return NULL;

	//implementation of FIRST FIT strategy
	struct Node* dummy=head;
	while(dummy->next!=NULL)	//iterate through the free list
	{
		if(dummy->next->length>=count)
		{
			if(dummy->next->length-count>sizeof(block))	//create a new block if there is space for a new array to be allocated
			{
				struct Node* new=(void*)((void*)dummy->next+sizeof(block)+count);
				if(dummy->next->next!=NULL)
				{
					new->next=dummy->next->next;
					dummy->next->next->prev=new;
				}
				new->prev=dummy->next;
				dummy->next->next=new;
				new->length=dummy->next->length-count-sizeof(block);

				dummy->next->length=count;
			}
			else		//what if size left is less than block but it may be used in future
			{
				heapinfo_node->leftout_free_space+=dummy->next->length-count;
			}
			void *p=(void*)((void*)dummy->next+sizeof(block));


			if(dummy->next->next!=NULL)
			{
				dummy->next->next->prev=dummy;
			}
			dummy->next=dummy->next->next;
			heapinfo_node->d+=1;
			
			struct Node* dummy2=head;
			heapinfo_node->c=0;
			heapinfo_node->e=head->length;
			heapinfo_node->f=head->length;
			heapinfo_node->c+=head->length;

			while(dummy2->next!=NULL)
			{
				dummy2=dummy2->next;
				heapinfo_node->c+=dummy2->length;
				if(dummy2->length<heapinfo_node->e)
				{
					heapinfo_node->e=dummy2->length;
				}
				if(dummy2->length>heapinfo_node->f)
					heapinfo_node->f=dummy2->length;
			}
			heapinfo_node->b+=count+sizeof(block);
			return p;
		}
		dummy=dummy->next;
	}

	struct Node* temp=(void*)((void*)head+count+sizeof(block));
	temp->length=head->length-count-sizeof(block);
	temp->prev=head->prev;
	temp->next=head->next;
	head=temp;

	struct Node* block_metadata;
	block_metadata=(void*)((void*)head-sizeof(block)-count);

	block_metadata->next=NULL;
	block_metadata->prev=NULL;
	block_metadata->length=count;

	heapinfo_node->d+=1;
	struct Node* dummy2=head;
	heapinfo_node->c=0;
	heapinfo_node->e=head->length;
	heapinfo_node->f=head->length;
	heapinfo_node->c+=head->length;

	while(dummy2->next!=NULL)
	{
		dummy2=dummy2->next;
		heapinfo_node->c+=dummy2->length;
		if(dummy2->length<heapinfo_node->e)
		{
			heapinfo_node->e=dummy2->length;
		}
		if(dummy2->length>heapinfo_node->f)
			heapinfo_node->f=dummy2->length;
	}
	heapinfo_node->b+=count+sizeof(block);
	return (void *)((void*)block_metadata+sizeof(block));
}

void my_free(void *ptr)
{
	struct Node* metadata=ptr-sizeof(block);

	heapinfo_node->b-=(metadata->length+sizeof(block));
	metadata->next=NULL;
	metadata->prev=NULL;
	struct Node* dummy=head;		
	while(dummy->next!=NULL)
	{
		dummy=dummy->next;
		if((void*)metadata<(void*)dummy)
		{
			dummy->prev->next=metadata;
			metadata->prev=dummy->prev;

			dummy->prev=metadata;
			metadata->next=dummy;
			break;
		}
	}
	if(dummy==head)
	{
		head->next=metadata;
		metadata->prev=head;
		metadata->next=NULL;

	}
	else if(dummy->next==NULL && dummy->prev!=metadata){		
	
		dummy->next=metadata;
		metadata->prev=dummy;
		metadata->next= NULL;
	}
	
	if(metadata->next!=NULL && (void*)metadata+metadata->length+sizeof(block)==(void*)metadata->next)
	{
		metadata->length+=sizeof(block)+metadata->next->length;
		if(metadata->next->next!=NULL)
		{
			metadata->next->next->prev=metadata;
		}

		metadata->next=metadata->next->next;
	}

	if(metadata->prev!=NULL && (void*)metadata->prev+sizeof(block)+metadata->prev->length==(void*)metadata)
	{
		metadata->prev->length+=sizeof(block)+metadata->length;
		metadata->prev->next=metadata->next;
		if(metadata->next!=NULL)
		{
			metadata->next->prev=metadata->prev;
		}	
	}

	struct Node* dummy3=head;
	heapinfo_node->c=0;
	heapinfo_node->e=head->length;
	heapinfo_node->f=head->length;
	heapinfo_node->c+=head->length;

	while(dummy3->next!=NULL)
	{
		dummy3=dummy3->next;
		heapinfo_node->c+=dummy3->length;
		if(dummy3->length<heapinfo_node->e)
		{
			heapinfo_node->e=dummy3->length;
		}
		if(dummy3->length>heapinfo_node->f)
			heapinfo_node->f=dummy3->length;
	}

	
	heapinfo_node->d-=1;
	return;
}

void my_clean()
{
	munmap((void*)head+sizeof(block)+head->length+sizeof(heapinfo)-4096,4096);
	return;
}
//Max size: 4096- head- heapinfo
//current size: head+heapinfo+(all nodes of allocated blocks+length of each allocated block)+node size of free list blocks
//				does not include length of free list blocks 
//free memory: 4096-head-heapinfo-(all nodes of allocated blocks+length of each allocated block)-node size of free list block
//			   Only addition of length of free list blocks+leftout space
//smallest chunk: min(head->length, free list block->length)
//if rest memory is less than sizeof(block) then include it in free memory
//free memory+current size=4096
void my_heapinfo(){
	int a,b,c,d,e,f;
	a=4096-sizeof(block)-sizeof(heapinfo);
	c=(heapinfo_node->c)+(heapinfo_node->leftout_free_space);
	if(heapinfo_node->b==48 && heapinfo_node->d==0 && c+sizeof(block)==head->length)	//no allocation took place 
		c+=sizeof(block);
	b=4096-c;	
	d=(heapinfo_node->d);
	e=(heapinfo_node->e);
	f=(heapinfo_node->f);

	// Do not edit below output format
	printf("=== Heap Info ================\n");
	printf("Max Size: %d\n", a);
	printf("Current Size: %d\n", b);
	printf("Free Memory: %d\n", c);
	printf("Blocks allocated: %d\n", d);
	printf("Smallest available chunk: %d\n", e);
	printf("Largest available chunk: %d\n", f);
	printf("==============================\n");
	// Do not edit above output format
	return;
}
